# FR Accounting & BTP Rules Registry — V1

**Référence : 8 août 2026**  
**Statut : draft à valider avant production**

## Contenu

- `registry.yaml` — source de vérité recommandée dans Git.
- `registry.json` — consommation moteur/API/MCP.
- `registry.csv` — revue par expert-comptable / juriste / product owner.
- `rule.schema.json` — validation structurelle d'une règle.

## Périmètre

- FR_GENERAL : 39 règles
- FR_BTP : 24 règles
- FR_BTP_PUBLIC : 9 règles
- Total : 72 règles
- Marquées `legal_review_required` : 17

## Convention

Chaque règle contient :
`id`, `version`, `module`, `nature`, `severity`, `effective_from`,
`applies_if`, `validation`, `effect`, `source`.

## Principe d'architecture

Le registre ne remplace pas le moteur.
Le moteur charge les règles applicables à une date donnée, exécute les calculs
déterministes, produit une décision et conserve les IDs/versions des règles appliquées.

## À valider avant mise en production

En priorité :
1. TVA BTP à 5,5 % / 10 % et toutes conditions d'éligibilité.
2. Exigibilité TVA et cas particuliers des acomptes.
3. Mentions exactes d'exonération/franchise/autoliquidation.
4. Conditions de délais de paiement dérogatoires.
5. Commande publique : avances, acomptes, révision/actualisation et DGD.
6. Règles d'avoirs/corrections de TVA.
7. Mapping comptable propre à chaque société.

Le registre conserve les sources officielles afin que chaque décision soit auditée.
